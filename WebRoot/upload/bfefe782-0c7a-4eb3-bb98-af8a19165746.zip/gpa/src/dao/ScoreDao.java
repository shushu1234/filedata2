package dao;

public class ScoreDao {
}
