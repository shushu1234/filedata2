package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import entity.Course;
import util.DBUtil;

public class CourseDao {
	public boolean insert(Course c) {
		return true;
	}

	public boolean update(Course c) {
		return true;
	}

	public boolean delete(String id) {
		return true;
	}
	public boolean save(Course c){
		if(c.getId()==null||"".equals(c.getId()))
		   return 	this.insert(c);
		else
		   return	this.update(c);
		
	}
    public Course queryById(String id){
    	Connection connection =null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		try {
			connection=DBUtil.getConnection();
			String sql = "select * from course where id=?";
			preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setString(1,id);
			resultSet = preparedStatement.executeQuery();
			if (resultSet.next()) {
				Course c = new Course();
				c.setId(resultSet.getString("id"));
				c.setName(resultSet.getString("name"));
				c.setCredithour(resultSet.getFloat("credithour"));
				c.setClasshour(resultSet.getInt("classhour"));
				c.setPracticehour(resultSet.getInt("practicehour"));
				c.setRemark(resultSet.getString("remark"));
				return c;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.closeConnection(connection, preparedStatement, resultSet);
		}
    	return null;
    }
	public List<Course> queryAll() {
		Connection connection =null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		try {
			connection=DBUtil.getConnection();
			String sql = "select * from course";
			preparedStatement = connection.prepareStatement(sql);
			resultSet = preparedStatement.executeQuery();
			List<Course> list = new ArrayList<Course>();
			while (resultSet.next()) {
				Course c = new Course();
				c.setId(resultSet.getString("id"));
				c.setName(resultSet.getString("name"));
				c.setCredithour(resultSet.getFloat("credithour"));
				c.setClasshour(resultSet.getInt("classhour"));
				c.setPracticehour(resultSet.getInt("practicehour"));
				c.setRemark(resultSet.getString("remark"));
				list.add(c);
			}
			return list;
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.closeConnection(connection, preparedStatement, resultSet);
		}
		return null;
	}
}
