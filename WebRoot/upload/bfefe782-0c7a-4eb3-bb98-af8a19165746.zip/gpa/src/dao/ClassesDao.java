package dao;

public class ClassesDao {

}
