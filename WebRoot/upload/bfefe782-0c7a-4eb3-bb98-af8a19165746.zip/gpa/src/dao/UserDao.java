package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import entity.User;
import util.DBUtil;

public class UserDao {
	public boolean login(String id, String pwd) {
		Connection connection=null;
		PreparedStatement preparedStatement=null;
		ResultSet resultSet=null;
		try {
			connection=DBUtil.getConnection();
			String sql = "select * from user where id='" + id + "' and pwd='"
					+ pwd + "'";
			preparedStatement=connection.prepareStatement(sql);
			resultSet=preparedStatement.executeQuery();
			if (resultSet.next())
				return true;
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBUtil.closeConnection(connection, preparedStatement, resultSet);
		}
		return false;
	}

	public User get(String id) {
		Connection connection=null;
		PreparedStatement preparedStatement=null;
		ResultSet resultSet=null;
		try {
			connection=DBUtil.getConnection();
			String sql = "select * from user where id='" + id + "'";
			preparedStatement=connection.prepareStatement(sql);
			resultSet=preparedStatement.executeQuery();
			if (resultSet.next()) {
				User u = new User();
				u.setPwd(resultSet.getString("pwd"));
				u.setId(resultSet.getString("id"));
				u.setName(resultSet.getString("name"));
				return u;
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBUtil.closeConnection(connection, preparedStatement, resultSet);
		}
		return null;
	}

}