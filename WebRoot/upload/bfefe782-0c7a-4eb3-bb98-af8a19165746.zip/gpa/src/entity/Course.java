package entity;

public class Course {
	private String id;//课程id
	private String name;//课程名
	private Float credithour;//学分
	private Integer classhour;//讲授学时
	private Integer practicehour;//实验学时
	private String remark;//
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Float getCredithour() {
		return credithour;
	}
	public void setCredithour(Float credithour) {
		this.credithour = credithour;
	}
	public Integer getClasshour() {
		return classhour;
	}
	public void setClasshour(Integer classhour) {
		this.classhour = classhour;
	}
	public Integer getPracticehour() {
		return practicehour;
	}
	public void setPracticehour(Integer practicehour) {
		this.practicehour = practicehour;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
}
