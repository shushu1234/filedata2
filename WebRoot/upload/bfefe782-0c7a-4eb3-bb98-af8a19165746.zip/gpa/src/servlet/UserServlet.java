package servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.UserDao;
import entity.User;

public class UserServlet extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

	   System.out.println("get method");
	}
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		UserDao ud=new UserDao();		
		request.setCharacterEncoding("UTF-8");
		String id=request.getParameter("user");
		String pwd=request.getParameter("passwd");
		if(ud.login(id, pwd)){
			HttpSession session=request.getSession();
			User user=ud.get(id);
			session.setAttribute("loginUser", user);
			request.getRequestDispatcher("main.jsp").forward(request, response);
		}else{
			request.setAttribute("errormessage","用户名密码错误");
			request.getRequestDispatcher("index.jsp").forward(request, response);
		}
	}

}
