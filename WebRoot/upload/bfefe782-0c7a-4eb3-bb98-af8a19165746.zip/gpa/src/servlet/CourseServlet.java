package servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import dao.CourseDao;
import entity.Course;

public class CourseServlet extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request,response);
	}
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String op=request.getParameter("op");
		CourseDao cd=new CourseDao();
		if("add".equals(op)){
			//1-1
			//接收数据，封装到Course 对象中
			String name=request.getParameter("name");
			String credithour=request.getParameter("credithour");
			Course c=new Course();
			c.setName(name);
			c.setCredithour(Float.parseFloat(credithour));
			request.setAttribute("course", c);
			response.setContentType("application/x-json;charset=UTF-8");
			PrintWriter out=response.getWriter();
			if(true){
				out.println("{\"message\":\"数据保存成功\"}");
				//request.setAttribute("message", "数据保存成功");
			}
			else {
				out.println("数据保存失败");
				//request.setAttribute("message", "数据保存失败");
			}
			out.flush();
			out.close();
			
			request.getRequestDispatcher("addUI.jsp").forward(request, response);
		}else if("del".equals(op)){
			//2
		}else if("saveUI".equals(op)){//课程添加或修改界面
			String id=request.getParameter("id");
			if(!(id==null||"".equals(id))){
				Course c=cd.queryById(id);
				request.setAttribute("course",c);
			}
			request.getRequestDispatcher("saveUI.jsp").forward(request,response);
		}if("save".equals(op)){
			//1-1
			//接收数据，封装到Course 对象中
			String id=request.getParameter("id");
			Course c=null;
			if(!(id==null||"".equals(id))){
				c=cd.queryById(id);
			}else
				c=new Course();
			String name=request.getParameter("name");
			String credithour=request.getParameter("credithour");
			c.setName(name);
			c.setCredithour(Float.parseFloat(credithour));
			response.setContentType("application/x-json;charset=UTF-8");
			PrintWriter out=response.getWriter();
			if(cd.save(c)){
				out.println("{\"message\":\"数据保存成功\"}");
			}
			else {
				out.println("{\"message\":\"数据保存失败\"}");
			}
			out.flush();
			out.close();
			
			request.getRequestDispatcher("addUI.jsp").forward(request, response);
		}else if(op==null||"list".equals(op)){
			//4
			List<Course> list=cd.queryAll();
			request.setAttribute("result",list);
			request.getRequestDispatcher("list.jsp").forward(request,response);
		}
	}

}
