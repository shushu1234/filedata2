/*
SQLyog 企业版 - MySQL GUI v8.14 
MySQL - 5.0.37-community-nt : Database - gpa
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`gpa` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `gpa`;

/*Table structure for table `classes` */

DROP TABLE IF EXISTS `classes`;

CREATE TABLE `classes` (
  `id` int(11) unsigned NOT NULL auto_increment COMMENT '班级Id',
  `name` varchar(20) NOT NULL COMMENT '名称',
  `grade` int(11) default NULL COMMENT '年级',
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `classes` */

insert  into `classes`(`id`,`name`,`grade`) values (1,'计科141',2014),(2,'计科142',2014),(3,'计科143',2014),(4,'计科144',2014),(5,'计科151',2015),(6,'计科152',2015);

/*Table structure for table `course` */

DROP TABLE IF EXISTS `course`;

CREATE TABLE `course` (
  `id` varchar(10) NOT NULL COMMENT '课程id',
  `name` varchar(30) default NULL COMMENT '课程名',
  `credithour` float default NULL COMMENT '学分',
  `classhour` int(11) default NULL COMMENT '讲授学时',
  `practicehour` int(11) default NULL COMMENT '实验学时',
  `remark` text COMMENT '备注',
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `course` */

insert  into `course`(`id`,`name`,`credithour`,`classhour`,`practicehour`,`remark`) values ('1','数据结构',4,64,16,NULL),('2','算法分析与设计',3,48,16,NULL);

/*Table structure for table `score` */

DROP TABLE IF EXISTS `score`;

CREATE TABLE `score` (
  `id` bigint(20) NOT NULL COMMENT '序号',
  `studentId` varchar(8) default NULL COMMENT '学生学号',
  `courseId` varchar(10) default NULL COMMENT '课程编号',
  `semester` varchar(15) default NULL COMMENT '开课学期',
  `score1` float default NULL COMMENT '一考成绩',
  `score2` float default NULL COMMENT '二考成绩',
  `score3` float default NULL COMMENT '三考成绩',
  PRIMARY KEY  (`id`),
  KEY `FK_score2` (`studentId`),
  KEY `FK_score1` (`courseId`),
  KEY `FK_score3` (`studentId`),
  KEY `FK_score4` (`courseId`),
  CONSTRAINT `FK_score3` FOREIGN KEY (`studentId`) REFERENCES `user` (`id`),
  CONSTRAINT `FK_score4` FOREIGN KEY (`courseId`) REFERENCES `course` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `score` */

/*Table structure for table `user` */

DROP TABLE IF EXISTS `user`;

CREATE TABLE `user` (
  `id` varchar(8) NOT NULL,
  `name` varchar(20) default NULL,
  `pwd` varchar(20) default NULL,
  `classesId` int(11) default NULL,
  `roleId` int(11) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `user` */

insert  into `user`(`id`,`name`,`pwd`,`classesId`,`roleId`) values ('14422002','丁二','123456',1,0),('14422003','张三','123456',1,0),('14422004','赵四','123456',1,0),('14422005','王五','123456',1,0),('14422006','陈六','123456',1,0),('14422007','钱七','123456',1,0),('14422008','胡八','123456',1,0),('14422009','范九','123456',1,0),('14422010','杜十','123456',1,0),('14422011','孙一','123456',1,0),('14422012','周五','123456',1,0),('14422013','武天','123456',1,0),('14422014','郑丽','123456',1,0),('15422001','王一','123456',1,1);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
